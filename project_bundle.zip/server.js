const http = require('http');
const url = require('url');
const fs = require('fs');
const { spawn, exec } = require('child_process');
const path = require('path');

const PORT = process.env.PORT || 3000;

const procs = new Map();
const streams = new Map();

function sendJSON(res, obj) {
  const s = JSON.stringify(obj);
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.end(s);
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); }
      catch (e) { resolve({}); }
    });
    req.on('error', reject);
  });
}

function sendSSE(res, event, data) {
  if (event) res.write(`event: ${event}\n`);
  const lines = String(data).split(/\r?\n/);
  for (const l of lines) {
    res.write(`data: ${l}\n`);
  }
  res.write('\n');
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  if (req.method === 'POST' && parsed.pathname === '/run-script') {
    const body = await parseBody(req);
    const script = body.script || 'myscript.sh';
    const scriptPath = path.resolve(__dirname, script);
    if (!fs.existsSync(scriptPath)) {
      res.statusCode = 400; return sendJSON(res, { error: 'Script not found: ' + scriptPath });
    }
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2,8);

    // Spawn the script using the system shell so scripts with shebang run properly
    const proc = spawn(scriptPath, { shell: true });
    procs.set(id, proc);
    streams.set(id, []);

    proc.stdout.on('data', d => {
      const text = d.toString();
      const arr = streams.get(id) || [];
      for (const r of arr) sendSSE(r, null, text);
    });
    proc.stderr.on('data', d => {
      const text = d.toString();
      const arr = streams.get(id) || [];
      for (const r of arr) sendSSE(r, 'stderr', text);
    });
    proc.on('close', code => {
      const arr = streams.get(id) || [];
      for (const r of arr) sendSSE(r, 'end', `Process exited with code ${code}`);
      for (const r of arr) r.end();
      streams.delete(id);
      procs.delete(id);
    });

    res.setHeader('Access-Control-Allow-Origin', '*');
    return sendJSON(res, { id });
  }

  if (req.method === 'GET' && parsed.pathname.startsWith('/stream/')) {
    const id = parsed.pathname.split('/')[2];
    if (!id || !procs.has(id)) {
      res.statusCode = 404; res.setHeader('Access-Control-Allow-Origin', '*'); return res.end('Not found');
    }
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    res.write('\n');
    const arr = streams.get(id) || [];
    arr.push(res);
    streams.set(id, arr);
    req.on('close', () => {
      const cur = streams.get(id) || [];
      const idx = cur.indexOf(res);
      if (idx !== -1) cur.splice(idx,1);
      streams.set(id, cur);
    });
    return;
  }

  if (req.method === 'POST' && parsed.pathname === '/ping') {
    const body = await parseBody(req);
    const hosts = Array.isArray(body.hosts) ? body.hosts : [];
    const results = [];
    const tasks = hosts.map(h => {
      return new Promise(resolve => {
        if (!h) return resolve({ host: h, ok: false, out: 'empty' });
        const cmd = process.platform === 'win32' ? `ping -n 1 ${h}` : `ping -c 1 ${h}`;
        exec(cmd, { timeout: 5000 }, (err, stdout, stderr) => {
          const ok = !err;
          resolve({ host: h, ok, out: (stdout || stderr || '').toString() });
        });
      }).then(r => results.push(r));
    });
    await Promise.all(tasks);
    res.setHeader('Access-Control-Allow-Origin', '*');
    return sendJSON(res, { results });
  }

  // default: serve a basic message
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.end('ObservEdge helper server\n');
});

server.listen(PORT, () => {
  console.log('Server listening on port', PORT);
  console.log('POST /run-script {script:"myscript.sh"} to start and GET /stream/:id to stream output');
});
