#!/bin/bash
set -e
 
LOG_FILE="install_log_$(date +%F_%H-%M-%S).log"
exec > >(tee -i $LOG_FILE)
exec 2>&1
 
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color
 
##############################################
# STEP 1: Hardware Capacity Check
##############################################
echo -e "${YELLOW}===================================="
echo "STEP 1: CHECKING SYSTEM HARDWARE"
echo -e "====================================${NC}"
 
# Minimum Requirements
MIN_CPU=4
MIN_RAM_GB=8
MIN_DISK_GB=150
 
FAIL_FLAG=0
 
# ---- CPU CHECK ----
CPU_CORES=$(nproc)
if [ "$CPU_CORES" -ge "$MIN_CPU" ]; then
  echo -e "CPU Cores: ${GREEN}${CPU_CORES} (OK)${NC}"
else
  echo -e "CPU Cores: ${RED}${CPU_CORES} (FAIL - Need ≥ ${MIN_CPU})${NC}"
  FAIL_FLAG=1
fi
 
# ---- MEMORY CHECK ----
MEM_TOTAL_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
MEM_TOTAL_GB=$((MEM_TOTAL_KB / 1024 / 1024))
if [ "$MEM_TOTAL_GB" -ge "$MIN_RAM_GB" ]; then
  echo -e "Memory: ${GREEN}${MEM_TOTAL_GB} GB (OK)${NC}"
else
  echo -e "Memory: ${RED}${MEM_TOTAL_GB} GB (FAIL - Need ≥ ${MIN_RAM_GB} GB)${NC}"
  FAIL_FLAG=1
fi
 
# ---- DISK CAPACITY CHECK ----
DISK_SIZE_GB=$(lsblk -b -dn -o SIZE | awk '{sum += $1} END {print int(sum / 1024 / 1024 / 1024)}')
if [ "$DISK_SIZE_GB" -ge "$MIN_DISK_GB" ]; then
  echo -e "Disk Size: ${GREEN}${DISK_SIZE_GB} GB (OK)${NC}"
else
  echo -e "Disk Size: ${RED}${DISK_SIZE_GB} GB (FAIL - Need ≥ ${MIN_DISK_GB} GB)${NC}"
  FAIL_FLAG=1
fi
 
echo -e "${YELLOW}====================================${NC}"
 
# ---- FINAL SUMMARY ----
if [ "$FAIL_FLAG" -eq 0 ]; then
  echo -e "${GREEN}✅ Overall System Status: OK — All hardware checks passed.${NC}"
else
  echo -e "${RED}❌ Overall System Status: FAILED — One or more hardware checks failed.${NC}"
  echo -e "${RED}Please upgrade your hardware and re-run the script.${NC}"
  exit 1
fi
 
##############################################
# STEP 2: Docker Installation / Validation
##############################################
echo -e "${YELLOW}===================================="
echo "STEP 2: CHECKING / INSTALLING DOCKER"
echo -e "====================================${NC}"
 
REQUIRED_DOCKER_VERSION="29.0.0"
REQUIRED_COMPOSE_VERSION="1.29.2"
 
install_docker() {
  echo -e "${YELLOW}⚙️  Installing/Updating Docker from local packages...${NC}"
  cd docker-setup/
  sudo dpkg -i *.deb
  cd ..
  sudo systemctl enable docker
  sudo systemctl start docker
}
 
# ---- DOCKER VALIDATION ----
if command -v docker >/dev/null 2>&1; then
  CURRENT_DOCKER_VERSION=$(docker --version | awk '{print $3}' | sed 's/,//')
  echo "Current Docker version: $CURRENT_DOCKER_VERSION"
  if [ "$(printf '%s\n' "$REQUIRED_DOCKER_VERSION" "$CURRENT_DOCKER_VERSION" | sort -V | head -n1)" != "$REQUIRED_DOCKER_VERSION" ]; then
    echo -e "${RED}❌ Docker version too low. Updating...${NC}"
    install_docker
  else
    echo -e "${GREEN}✅ Docker version OK${NC}"
  fi
else
  echo -e "${RED}❌ Docker not installed. Installing...${NC}"
  install_docker
fi
 
# Recheck Docker
if command -v docker >/dev/null 2>&1; then
  docker --version
else
  echo -e "${RED}❌ Docker installation failed — Please check your .deb files${NC}"
  exit 1
fi
 
# ---- DOCKER COMPOSE VALIDATION ----
if docker compose version >/dev/null 2>&1; then
  CURRENT_COMPOSE_VERSION=$(docker compose version | awk '{print $3}' | sed 's/v//')
  echo "Current Docker Compose version: $CURRENT_COMPOSE_VERSION"
  if [ "$(printf '%s\n' "$REQUIRED_COMPOSE_VERSION" "$CURRENT_COMPOSE_VERSION" | sort -V | head -n1)" != "$REQUIRED_COMPOSE_VERSION" ]; then
    echo -e "${RED}❌ Docker Compose version too low. Updating...${NC}"
    install_docker
  else
    echo -e "${GREEN}✅ Docker Compose version OK${NC}"
  fi
else
  echo -e "${RED}❌ Docker Compose not found — Installing compose plugin...${NC}"
  install_docker
fi
 
##############################################
# STEP 3: Load Docker Images & Start Stack
##############################################
echo -e "${YELLOW}===================================="
echo "STEP 3: LOADING OBSERVABILITY STACK"
echo -e "====================================${NC}"
 
echo ">>> Extracting observability-docker.tar.gz"
tar -xzvf observability-docker.tar.gz
 
echo ">>> Importing Docker images"
cd observability/images/
for i in *.tar; do
  echo "Loading image: $i"
  sudo docker load -i "$i"
done
 
cd ..
echo ">>> Starting services"
sudo docker compose up -d
 
echo ">>> Verifying container status"
docker ps -a
 
echo -e "${GREEN}===================================="
echo "✅ Setup Completed Successfully!"
echo -e "====================================${NC}"