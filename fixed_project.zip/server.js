// server.js
const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');
const { spawn, exec } = require('child_process');

const PORT = process.env.PORT || 3000;
const procs = new Map();     // id -> child process
const streams = new Map();   // id -> [SSE response objects]

function sendJSON(res, obj, status = 200) {
  const s = JSON.stringify(obj);
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.end(s);
}

function parseBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); } catch { resolve({}); }
    });
  });
}

function sendSSE(res, event, data) {
  if (event) res.write(`event: ${event}\n`);
  String(data).split(/\r?\n/).forEach(line => res.write(`data: ${line}\n`));
  res.write('\n');
}

function serveFile(res, filePath, contentType = 'text/html') {
  try {
    const content = fs.readFileSync(filePath);
    res.writeHead(200, {
      'Content-Type': contentType,
      'Access-Control-Allow-Origin': '*',
    });
    res.end(content);
  } catch (e) {
    res.writeHead(404, { 'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*' });
    res.end('Not found');
  }
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);

  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }

  // Serve UI
  if (req.method === 'GET' && (parsed.pathname === '/' || parsed.pathname === '/new.html')) {
    return serveFile(res, path.join(__dirname, 'new.html'), 'text/html');
  }

  // Start script and stream output
  if (req.method === 'POST' && parsed.pathname === '/run-script') {
    const body = await parseBody(req);
    const script = body.script || 'myscript.sh';
    const scriptPath = path.resolve(__dirname, script);

    if (!fs.existsSync(scriptPath)) {
      return sendJSON(res, { error: 'Script not found', scriptPath }, 400);
    }
    // ensure executable
    try { fs.chmodSync(scriptPath, 0o755); } catch {}

    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

    // Use bash + stdbuf for line-buffered output so SSE updates promptly
    const child = spawn('bash', ['-lc', `stdbuf -oL -eL "${scriptPath}"`], { cwd: __dirname });

    procs.set(id, child);
    streams.set(id, []);

    child.stdout.on('data', (buf) => {
      const text = buf.toString();
      const subs = streams.get(id) || [];
      for (const r of subs) sendSSE(r, 'stdout', text);
    });

    child.stderr.on('data', (buf) => {
      const text = buf.toString();
      const subs = streams.get(id) || [];
      for (const r of subs) sendSSE(r, 'stderr', text);
    });

    child.on('close', (code) => {
      const subs = streams.get(id) || [];
      for (const r of subs) {
        sendSSE(r, 'end', `Process exited with code ${code}`);
        r.end();
      }
      streams.delete(id);
      procs.delete(id);
    });

    return sendJSON(res, { id });
  }

  // Subscribe to SSE stream for a run
  if (req.method === 'GET' && parsed.pathname.startsWith('/stream/')) {
    const id = parsed.pathname.split('/')[2];
    if (!id || !procs.has(id)) {
      res.statusCode = 404;
      res.setHeader('Access-Control-Allow-Origin', '*');
      return res.end('Not found');
    }
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
    });
    res.write('\n');

    const subs = streams.get(id) || [];
    subs.push(res);
    streams.set(id, subs);

    req.on('close', () => {
      const cur = streams.get(id) || [];
      const idx = cur.indexOf(res);
      if (idx !== -1) cur.splice(idx, 1);
      streams.set(id, cur);
    });
    return;
  }

  // Ping multiple hosts once
  if (req.method === 'POST' && parsed.pathname === '/ping') {
    const body = await parseBody(req);
    const hosts = Array.isArray(body.hosts) ? body.hosts : [];
    const results = [];

    await Promise.all(
      hosts.map((h) =>
        new Promise((resolve) => {
          if (!h) return resolve({ host: h, ok: false, out: 'empty' });
          const cmd = process.platform === 'win32' ? `ping -n 1 ${h}` : `ping -c 1 ${h}`;
          exec(cmd, { timeout: 5000 }, (err, stdout, stderr) => {
            const ok = !err;
            resolve({ host: h, ok, out: (stdout || stderr || '').toString() });
          });
        }).then((r) => results.push(r))
      )
    );

    return sendJSON(res, { results });
  }

  // Kill a running script (optional)
  if (req.method === 'POST' && parsed.pathname === '/kill') {
    const body = await parseBody(req);
    const id = body.id;
    const p = procs.get(id);
    if (!p) return sendJSON(res, { ok: false, error: 'No such run id' }, 404);
    try {
      p.kill('SIGTERM');
      return sendJSON(res, { ok: true });
    } catch (e) {
      return sendJSON(res, { ok: false, error: String(e) }, 500);
    }
  }

  // Fallback
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.end('ObservEdge helper server\n');
});

server.listen(PORT, () => {
  console.log('Server listening on port', PORT);
  console.log('POST /run-script {"script":"myscript.sh"} and GET /stream/:id to stream output');
});

