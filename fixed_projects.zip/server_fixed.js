const http = require("http");
const url = require("url");
const fs = require("fs");
const path = require("path");
const { spawn, exec } = require("child_process");

const PORT = process.env.PORT || 3000;
const procs = new Map();
const streams = new Map();

function mimeType(ext) {
  return {
    ".html": "text/html",
    ".css": "text/css",
    ".js": "application/javascript",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml",
  }[ext] || "application/octet-stream";
}

function serveFile(res, filePath) {
  try {
    const ext = path.extname(filePath).toLowerCase();
    const content = fs.readFileSync(filePath);
    res.writeHead(200, {
      "Content-Type": mimeType(ext),
      "Access-Control-Allow-Origin": "*",
    });
    res.end(content);
  } catch (e) {
    res.writeHead(404);
    res.end("Not Found");
  }
}

function sendJSON(res, obj, status = 200) {
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  });
  res.end(JSON.stringify(obj));
}

function sendSSE(res, event, data) {
  if (event) res.write(`event: ${event}
`);
  String(data)
    .split(/\r?\n/)
    .forEach((line) => res.write(`data: ${line}\n`));
  res.write("\n");
}

async function parseBody(req) {
  return new Promise((resolve) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      try {
        resolve(JSON.parse(body || "{}"));
      } catch {
        resolve({});
      }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    });
    return res.end();
  }

  const staticExt = path.extname(pathname).toLowerCase();
  if ([".png", ".jpg", ".jpeg", ".svg", ".css", ".js"].includes(staticExt)) {
    const target = path.join(__dirname, pathname);
    return serveFile(res, target);
  }

  if (pathname === "/" || pathname === "/new.html") {
    return serveFile(res, path.join(__dirname, "new.html"));
  }

  if (pathname === "/run-script" && req.method === "POST") {
    const body = await parseBody(req);
    const script = body.script || "myscript.sh";
    const scriptPath = path.join(__dirname, script);

    if (!fs.existsSync(scriptPath)) {
      return sendJSON(res, { error: "Script not found" }, 404);
    }

    fs.chmodSync(scriptPath, 0o755);

    const id =
      Date.now().toString(36) + Math.random().toString(36).substring(2, 8);

    const child = spawn("bash", ["-lc", `stdbuf -oL -eL "${scriptPath}"`], {
      cwd: __dirname,
    });

    procs.set(id, child);
    streams.set(id, []);

    child.stdout.on("data", (buf) => {
      const subs = streams.get(id) || [];
      for (const r of subs) sendSSE(r, "stdout", buf.toString());
    });

    child.stderr.on("data", (buf) => {
      const subs = streams.get(id) || [];
      for (const r of subs) sendSSE(r, "stderr", buf.toString());
    });

    child.on("close", (code) => {
      const subs = streams.get(id) || [];
      for (const r of subs) {
        sendSSE(r, "end", `Process exited with code ${code}`);
        r.end();
      }
      streams.delete(id);
      procs.delete(id);
    });

    return sendJSON(res, { id });
  }

  if (pathname.startsWith("/stream/")) {
    const id = pathname.split("/")[2];
    if (!procs.has(id)) {
      res.writeHead(404);
      return res.end("No such process");
    }

    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "Access-Control-Allow-Origin": "*",
    });

    const subs = streams.get(id);
    subs.push(res);

    req.on("close", () => {
      const list = streams.get(id);
      const index = list.indexOf(res);
      if (index !== -1) list.splice(index, 1);
    });

    return;
  }

  if (pathname === "/ping" && req.method === "POST") {
    const body = await parseBody(req);
    const hosts = Array.isArray(body.hosts) ? body.hosts : [];
    const results = [];

    await Promise.all(
      hosts.map(
        (h) =>
          new Promise((resolve) => {
            const cmd = `ping -c 1 ${h}`;
            exec(cmd, { timeout: 5000 }, (err, stdout, stderr) => {
              resolve({
                host: h,
                ok: !err,
                out: stdout || stderr || "",
              });
            });
          }).then((r) => results.push(r))
      )
    );

    return sendJSON(res, { results });
  }

  res.writeHead(404);
  res.end("Not Found");
});

server.listen(PORT, () => {
  console.log("Server running on", PORT);
});
